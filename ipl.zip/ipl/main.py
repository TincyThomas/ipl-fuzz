import sys
from predictor import predictRuns
runs = predictRuns('May-04-inn2.csv')
print('Predicted Runs: ', runs)